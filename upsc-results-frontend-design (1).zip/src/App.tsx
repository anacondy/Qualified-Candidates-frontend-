
import React, { useState, useEffect, useRef } from 'react';
import { Search, FileDown, AlignLeft } from 'lucide-react';

// --- MOCK DATA ---
const generateMockData = (count: number) => {
  const data = [];
  for (let i = 1; i <= count; i++) {
    const year = Math.random() > 0.5 ? 2025 : 2026;
    data.push({
      id: `#${String(i).padStart(4, '0')}`,
      rollNumber: `084${String(Math.floor(Math.random() * 90000) + 10000).padStart(5, '0')}`,
      name: `Candidate ${i}`,
      exam: 'Civil Services',
      stage: ['Prelims', 'Mains', 'Interview'][Math.floor(Math.random() * 3)],
      category: 'General',
      status: 'Cross-Checked',
      year: year,
    });
  }
  return data;
};

const initialData = generateMockData(50);

const App: React.FC = () => {
  const [data, setData] = useState(initialData);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeStage, setActiveStage] = useState('All');
  const [activeExam, setActiveExam] = useState('All');
  const [highlightedRow, setHighlightedRow] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.key === 'k') {
        event.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    let filteredData = initialData;

    if (activeStage !== 'All') {
      filteredData = filteredData.filter(item => item.stage === activeStage);
    }
    if (activeExam !== 'All') {
      filteredData = filteredData.filter(item => item.exam === activeExam);
    }
    if (searchTerm) {
        filteredData = filteredData.filter(item =>
            item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.rollNumber.includes(searchTerm)
        );
    }

    setData(filteredData);
  }, [searchTerm, activeStage, activeExam]);

  const handleSearchSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (data.length > 0) {
          const firstMatchId = data[0].id;
          setHighlightedRow(firstMatchId);
          const element = document.getElementById(firstMatchId);
          element?.scrollIntoView({ behavior: 'smooth', block: 'center' });
          setTimeout(() => {
              setHighlightedRow(null);
          }, 1500);
      }
  };


  return (
    <div className="bg-[#F0F0F0] min-h-screen font-mono text-black p-4 sm:p-6 lg:p-8">
        <div 
            className="absolute top-0 left-0 w-full h-full" 
            style={{
                backgroundImage: `url("data:image/svg+xml;utf8,<svg width='100%' height='100%' xmlns='http://www.w3.org/2000/svg'><defs><pattern id='grid' width='30' height='30' patternUnits='userSpaceOnUse'><path d='M0 30 L30 30 L30 0' fill='none' stroke='rgba(200,200,200,0.5)' stroke-width='1'/></pattern></defs><rect width='100%' height='100%' fill='url(%23grid)'/></svg>")`,
                backgroundRepeat: 'repeat'
            }}
        ></div>
      <div className="relative z-10">
        <header className="flex justify-between items-center mb-8">
          <div className="text-xs">
            <p>[SYSTEM]</p>
            <p>UPSC.QUALIFIERS</p>
          </div>
          <button className="sm:hidden">
            <AlignLeft size={24} />
          </button>
        </header>

        <div className="mb-12">
          <h1 className="text-6xl sm:text-8xl lg:text-9xl font-bold tracking-tighter relative">
            <span className="text-transparent" style={{ WebkitTextStroke: '2px black' }}>QUALIFIED</span>
            <span className="absolute left-0 top-0 text-black">QUALIFIED</span>
          </h1>
          <h1 className="text-6xl sm:text-8xl lg:text-9xl font-bold tracking-tighter relative -mt-4 sm:-mt-8">
            <span className="text-transparent" style={{ WebkitTextStroke: '2px black' }}>CANDIDATES</span>
             <span className="absolute left-0 top-0 text-black">CANDIDATES</span>
          </h1>
        </div>

        <p className="max-w-3xl text-sm mb-10">
          Official verified database of Union Public Service Commission examination qualifiers. Data cross-referenced from UPSC.gov.in, official PDFs, and AI-verified sources. Updated in real-time through automated systems.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white/80 border-2 border-black p-3 flex flex-col justify-center items-center backdrop-blur-sm">
            <p className="text-xs">TOTAL RECORDS</p>
            <p className="text-2xl font-bold">{initialData.length.toString().padStart(5, '0')}</p>
          </div>
          <div className="bg-white/80 border-2 border-black p-3 flex flex-col justify-center items-center backdrop-blur-sm">
            <p className="text-xs">VERIFIED (2025/26)</p>
            <p className="text-2xl font-bold">{initialData.filter(d => [2025, 2026].includes(d.year)).length.toString().padStart(5, '0')}</p>
          </div>
        </div>

        {/* --- CONTROLS --- */}
        <div className="border-2 border-black bg-white/80 backdrop-blur-sm mb-6">
          <div className="flex flex-col sm:flex-row items-center border-b-2 border-black">
            <form onSubmit={handleSearchSubmit} className="flex-grow w-full">
              <div className="flex items-center">
                <Search className="mx-3" size={18}/>
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="Ctrl+K to search name or roll number..."
                  className="w-full bg-transparent py-3 focus:outline-none"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </form>
            <button className="font-bold py-3 px-6 border-l-2 border-black w-full sm:w-auto hover:bg-black hover:text-white transition-colors">
              <FileDown size={18} className="inline mr-2"/>
              EXPORT
            </button>
          </div>
          <div className="flex flex-col sm:flex-row">
            <div className="p-3 flex items-center gap-3">
              <span className="text-xs">Stage:</span>
              <select onChange={(e) => setActiveStage(e.target.value)} value={activeStage} className="bg-transparent border border-black px-2">
                <option>All</option>
                <option>Prelims</option>
                <option>Mains</option>
                <option>Interview</option>
              </select>
            </div>
             <div className="p-3 flex items-center gap-3 border-t-2 sm:border-t-0 sm:border-l-2 border-black">
              <span className="text-xs">Exam:</span>
               <select onChange={(e) => setActiveExam(e.target.value)} value={activeExam} className="bg-transparent border border-black px-2">
                <option>All</option>
                <option>Civil Services</option>
              </select>
            </div>
          </div>
        </div>

        {/* --- DATA TABLE --- */}
        <div className="overflow-x-auto border-2 border-black bg-white/50 backdrop-blur-sm">
            <div className="p-3 border-b-2 border-black text-xs">
                Showing {data.length} of {initialData.length} records.
            </div>
            <div>
                {data.map(item => (
                    <div
                        id={item.id}
                        key={item.id}
                        className={`grid grid-cols-1 sm:grid-cols-12 gap-y-2 gap-x-4 p-4 border-b-2 border-black transition-colors duration-1000 ${highlightedRow === item.id ? 'bg-green-300' : 'hover:bg-gray-200/50'}`}
                    >
                        <div className="sm:col-span-1 font-bold text-gray-500 text-sm">{item.id}</div>
                        <div className="sm:col-span-2">
                            <p className="text-xs text-gray-500">ROLL NUMBER</p>
                            <p className="font-bold">{item.rollNumber}</p>
                        </div>
                        <div className="sm:col-span-3">
                            <p className="text-xs text-gray-500">CANDIDATE NAME</p>
                            <p className="font-bold text-lg">{item.name}</p>
                        </div>
                        <div className="sm:col-span-2">
                            <p className="text-xs text-gray-500">EXAM</p>
                            <p>{item.exam}</p>
                        </div>
                        <div className="sm:col-span-1">
                            <p className="text-xs text-gray-500">STAGE</p>
                            <p>{item.stage}</p>
                        </div>
                        <div className="sm:col-span-1">
                            <p className="text-xs text-gray-500">YEAR</p>
                            <p>{item.year}</p>
                        </div>
                        <div className="sm:col-span-2 text-right">
                           <p className="text-xs text-gray-500">STATUS</p>
                           <p className="font-semibold">{item.status}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>

        <footer className="text-center text-xs text-gray-500 mt-8">
          <p>Data sourced from upsc.gov.in. Always cross-verify with official sources.</p>
          <p>Last updated: {new Date().toISOString().split('T')[0]}</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
